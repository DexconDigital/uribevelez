<?php

function Conect()
{
   $echo = mysqli_connect("localhost","biinyuco_afizus","Afiz2018*","biinyuco_tutecho");
    return $echo;
}

?>
